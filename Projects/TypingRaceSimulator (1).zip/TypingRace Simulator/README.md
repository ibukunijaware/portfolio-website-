# TypingRaceSimulator

Object Oriented Programming Project — ECS414U

## Project Overview
This project is an Object-Oriented Programming simulation of a tying race with both a terminal-based interface(Part 1 ) and a Graphical User Interface

## Setup instructions 
1. Clone this repository to your local machine:
'https://github.com/ibukunijaware/TypingRaceSimulator.git'
2. Ensure you have the Java Devlopment Kit (JDK) 11 or higher installed and added to your system PATH. 


## Project Structure

```
TypingRaceSimulator/
├── .git/     # Git respository folder (hidden)
├── Part1/    # Code for Part I (textual version)
├──  Part2/    # Code for Part II (Graphical version)
├── README     # Compilation and exection of instructions
└──Report.pdf # Detailed project responses
```



## Guidelines 
## Part 1 - Textual Simulation 
1. Locate the 'Part1/' directory
2. Compile the source code: 'javac Typist.java TypingRace.java'
3. Execute the simulation ensuring that your 'main' method invokes 'startRace()': 'java TypingRace'


## Part 2 — GUI Simulation

1. Locate the Part2/ directory
2. Compile and run the GUI application using your preferred development environment
3. Initiate the graphical race by calling the 'startRaceGUI()' method 

## Dependencies

- Java Development Kit (JDK) 11 or higher
- No external libraries required for Part 1
- Part 2 may use Java Swing (included in standard JDK) or JavaFX

## Branching Information 
1. All development for the GUI module(Part II) is tracked on the 'gui development' branch to keep the 'main' branch stable 
2. The 'main' branch contains the finalized and stable code for Part I. 
