package Part2;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import Part1.TypingRace; // Accessing the TypingRace class from Part1
import Part1.Typist; // Accessing the Typist class from Part1

public class RacePanel extends JPanel {
    private MainGUI mainGUI ;
    private TypingRace race;
    private Timer raceTimer;
   

    public RacePanel(MainGUI mainGUI){
        this.mainGUI = mainGUI;
        this.setBackground(Color.WHITE);

        // Timer ticks 5 times per second (200ms intervals)
        raceTimer = new Timer (200, e -> updateRaceLogic());
    }

    public void setRace(TypingRace race) {
        this.race = race;
        repaint();// Show the starting state
    }

    public void beginRace() {
        if( race != null ) {
            raceTimer.start();
        }
    }

    private void updateRaceLogic() {
       if (race == null) return;
       // Advance one step 
       race.step();
       // Go back a step 
       repaint();
       //Check if we should stop 
       if(race.isRaceFinished()){
            raceTimer.stop();

            Typist winner =race.getWinner();

            // Brief delay so the user sees the winner before switching to results screen
            Timer transitionDelay = new Timer(800, ev -> mainGUI.showResults(race, winner));
            transitionDelay.setRepeats(false);
            transitionDelay.start();
       } 
    }   

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (race == null) return;

        Graphics2D g2d = (Graphics2D)g;
        g2d.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();
        int padding = 80;
        int rightPadding = 40;
        int trackLength = width - padding - rightPadding;

        List<Typist> typists = race.getTypists();
        int numTypists = typists.size();
        int trackHeight =(height -40) / numTypists;

        for(int i=0; i< numTypists; i++){
            Typist t = typists.get(i);
            int yPosition = 30 + (i * trackHeight) + (trackHeight / 2);

            double progressRatio = (double)t.getProgress() / race.getPassageLength();
            int x = padding + (int)(progressRatio * trackLength);

            // Draw track line
            g2d.setColor(Color.LIGHT_GRAY);
            g2d.drawLine(padding, yPosition, width - rightPadding, yPosition);

            //Retrieve the state
            boolean isMistyped = race.getMistypedState(i);

            // Draw typist
            g2d.setFont(new Font ("SansSerif", Font.BOLD, 28));

            if(t.isBurntOut()){
                g2d.setColor(Color.RED);
                g2d.drawString(t.getSymbol() + " (zzz)", x, yPosition); 
            }
            else if(isMistyped){
                g2d.setColor(Color.ORANGE);
                g2d.drawString(t.getSymbol() + " [<]", x, yPosition);
            }
            else{
                g2d.setColor(Color.BLUE);
                g2d.drawString(String.valueOf(t.getSymbol()), x, yPosition);
            }

            // Draw player label
            g2d.setColor(Color.BLACK);
            g2d.setFont(new Font ("SansSerif", Font.PLAIN, 14));
            g2d.drawString("Player " + (i + 1), 10, yPosition + 5);
        }
    }   
    //Getter used by MainGUI to pass sata to ResultPanel
    public TypingRace getRace(){
        return this.race;
    }
}
