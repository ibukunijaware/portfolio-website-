package Part2;

import javax.swing.*;
import java.awt.*;
import Part1.TypingRace; // Accessing the TypingRace class from Part1
import Part1.Typist; // Accessing the Typist class from Part1

public class MainGUI extends JFrame{
    private CardLayout cardLayout ;
    private JPanel mainPanel ;


    // Parts 
    private SetupPanel setupPanel ;
    private RacePanel racePanel ;
    private ResultPanel resultPanel ;
    private GlobalStats globalStats;
    private LeaderBoardPanel leaderboardPanel;

    public MainGUI() {
        setTitle("Typing Race Simulator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800,600);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // Initialize panels
        setupPanel = new SetupPanel(this, globalStats);
        racePanel = new RacePanel(this);
        globalStats = new GlobalStats();
        resultPanel = new ResultPanel(this, globalStats);
        leaderboardPanel = new LeaderBoardPanel(this);
        

        // Add panels to mainPanel
        mainPanel.add(setupPanel, "SETUP");
        mainPanel.add(racePanel, "RACE");
        mainPanel.add(resultPanel, "RESULT");
        mainPanel.add(leaderboardPanel, "GLOBAL");
        

        add(mainPanel);
        cardLayout.show(mainPanel, "SETUP");

        this.setLocationRelativeTo(null); // Center the window
        setVisible(true);

    }

    // Method to switch panels
    public void startRace(TypingRace race) {
        racePanel.setRace(race);
        cardLayout.show(mainPanel, "RACE");
        racePanel.beginRace();
    }

    public void showResults(TypingRace race, Typist winner) {
        resultPanel.setResults(race, winner);
        cardLayout.show(mainPanel, "RESULT");
    }

    public void showSetup() {
        cardLayout.show(mainPanel, "SETUP");
    }

    public GlobalStats getGlobalStats() {
        return globalStats;
    }

    public void showGlobalStats() {
        leaderboardPanel.updateStats(globalStats);
        cardLayout.show(mainPanel, "GLOBAL");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainGUI());
    }
}
 

    