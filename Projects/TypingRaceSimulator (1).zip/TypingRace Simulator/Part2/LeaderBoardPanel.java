
package Part2;
import javax.swing.*;

public class LeaderBoardPanel extends JPanel {
    private JTextArea displayArea = new JTextArea();

    public LeaderBoardPanel(MainGUI gui) {
        add(new JScrollPane(displayArea));
    }

    public void updateStats(GlobalStats stats) {
        displayArea.setText("Current Leaderboard:\n" + stats.getLeaderboard().toString());
    }
}