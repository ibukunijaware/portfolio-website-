package Part2;

import java.util.HashMap;
import java.util.Map;

public class GlobalStats {
    private Map<String, Integer> leaderboard= new HashMap<>();
    private Map<String, Integer> consecutiveWins= new HashMap<>();
    private Map<String, Integer> cleanRace= new HashMap<>();

   public int getPoints(String playerName){
        return leaderboard.getOrDefault(playerName, 0);
    }
    
    public void updateLeaderboard(String playerName, int score, boolean wonCleanRace, boolean stayedCool){ 
        leaderboard.put(playerName, leaderboard.getOrDefault(playerName, 0) + score);
        if(wonCleanRace){
            consecutiveWins.put(playerName, consecutiveWins.getOrDefault(playerName, 0) + 1);
        }
        else{
            consecutiveWins.put(playerName, 0);
        }

        //Track "Iron Fingers" (No burnouts)
        if(stayedCool){
            cleanRace.put(playerName, cleanRace.getOrDefault(playerName, 0) + 1);
        }
    }

    public String getTitle(String playerName){
        if(consecutiveWins.getOrDefault(playerName, 0) >= 3){
            return "Speed Demon";
        }
        else if(cleanRace.getOrDefault(playerName, 0) >= 5){
            return "Iron Fingers";
        }
        else{
            return "Rookie";
        }
    }

    public double getRankAdjustment(String playerName){
        // Champions face higher expectations
        return (leaderboard.getOrDefault(playerName, 0) >= 10) ? -0.02 : 0.0;
    }

    public Map<String, Integer> getLeaderboard() {
        return leaderboard;
    }
}
