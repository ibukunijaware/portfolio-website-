package Part2;

import javax.swing.*;
import java.awt.*;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import Part1.TypingRace; // Accessing the TypingRace class from Part1
import Part1.Typist; // Accessing the Typist class from Part1

public class ResultPanel extends JPanel {
    private MainGUI mainGUI ;
    private JLabel winnerLabel ;
    private JPanel statsPanel;
    private GlobalStats globalStats;

    public ResultPanel(MainGUI mainGUI, GlobalStats globalStats) {
        this.globalStats = globalStats;
        this.mainGUI = mainGUI;

        this.setLayout(new BorderLayout(20,20));
        this.setBorder(BorderFactory.createEmptyBorder(30,30,30,30));

        //Header 
        winnerLabel = new JLabel("RACE FINISHED!", SwingConstants.CENTER);
        winnerLabel.setFont(new Font("Serif", Font.BOLD, 32));
        add(winnerLabel, BorderLayout.NORTH);

        statsPanel = new JPanel();
        statsPanel.setLayout(new BoxLayout(statsPanel, BoxLayout.Y_AXIS));
        add(new JScrollPane(statsPanel), BorderLayout.CENTER);

        //Bottom: Navigation
        JButton restartButton = new JButton("New Race");
        restartButton.addActionListener(e -> mainGUI.showSetup());
        add(restartButton, BorderLayout.SOUTH);
    }

    public int getPoints(String playerName){
        return globalStats.getPoints(playerName);
    }

    public void setResults(TypingRace race, Typist winner) {
        //Calculate points before displaying results
        calculateAndDisplayGlobalStats(race, this.globalStats);
        // Update header
        if(winner !=null){
            winnerLabel.setText("Winner: " + winner.getName() + " (" + winner.getSymbol() + ")");
        } 

        // Clear previous stats
        statsPanel.removeAll();

        // Sort typists by progress for display
        List<Typist> typists = race .getTypists();

        // Sorting by progress in descending order
        typists.sort((t1,t2) -> Integer.compare(t2.getProgress(), t1.getProgress()));

        // Add a row for each typist
        for(int i =0; i<typists.size(); i++){
            Typist t = typists.get(i);

            //Calculate WPM
            int wpm = (int)((t.getProgress() / 5));
            double accuracy = t.getAccuracy() * 100; // Convert to percentage

            JPanel row = new JPanel(new GridLayout(1,7));
            row.setBorder(BorderFactory.createMatteBorder(0,0,1,0,Color.GRAY));

            row.add(new JLabel((i+1) + ". " + t.getName() ));
            row.add(new JLabel("Symbol: " + t.getSymbol()));
            row.add(new JLabel("Total Points: " + globalStats.getPoints(t.getName())));
            row.add (new JLabel("Progress: " + t.getProgress()));
            row.add(new JLabel("Title: " + globalStats.getTitle(t.getName())));
            row.add(new JLabel (String.format("Accuracy: %.1f%%", accuracy)));
            row.add(new JLabel("WPM: " + wpm));

            statsPanel.add(row);
            statsPanel.add(Box.createRigidArea(new Dimension(0,10))); // Add spacing between rows
        }
        statsPanel.revalidate();
        statsPanel.repaint();
    }

    public void calculateAndDisplayGlobalStats(TypingRace race, GlobalStats stats){
        List<Typist> typists = race.getTypists();
        // Sort typists by progress in descending order
        typists.sort((t1,t2) -> Integer.compare(t2.getProgress(), t1.getProgress()));

        for(int i=0; i<typists.size(); i++){
            Typist t = typists.get(i);
            int points =0;

            if(i==0){
                points += 3; // Winner gets 3 points
            } else if(i==1){
                points += 2; // Second place gets 2 points
            } else if(i==2){
                points += 1; // Third place gets 1 points
            }
            int wpm = (int)((t.getProgress() / 5));
            if (wpm > 15) points +=1; // Bonus point for good speed

            boolean wonCleanRace = (i==0);
            boolean stayedCool = !t.isBurntOut();

            stats.updateLeaderboard(t.getName(), points, wonCleanRace, stayedCool);
        }
    }
}