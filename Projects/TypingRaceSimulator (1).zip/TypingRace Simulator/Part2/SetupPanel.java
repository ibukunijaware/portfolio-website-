package Part2;

import javax.swing.*;
import java.awt.*;
import Part1.TypingRace; // Accessing the TypingRace class from Part1
import Part1.Typist; // Accessing the Typist class from Part1

public class SetupPanel extends JPanel {
    private MainGUI mainGUI ;
    private GlobalStats globalStats;
    private JComboBox<String> passageSelector ;
    private JSpinner seatCountSpinner;
    private JCheckBox autoCorrect, caffeineMode, nightShift; 


    public SetupPanel(MainGUI mainGUI, GlobalStats globalStats) {
        this.mainGUI = mainGUI;
        this.globalStats = globalStats;

        setLayout(new GridLayout(6,1,10,10));// 6 rows, 1 column, with spacing

        // Passage selection
        JPanel passagePanel = new JPanel();
        passagePanel.add(new JLabel("Select Passage:"));
        passageSelector = new JComboBox<>(new String [] {"Short Passage (25 Characters)", "Medium Passage (50 Characters)", "Long Passage (100 Characters)"});
        passagePanel.add(passageSelector);
        add(passagePanel);

        // Seat count 
        JPanel seatPanel = new JPanel();
        seatPanel.add(new JLabel("Number of Seats(2-6):"));
        seatCountSpinner = new JSpinner(new SpinnerNumberModel(2, 2, 6, 1));
        seatPanel.add(seatCountSpinner);
        add(seatPanel);

        //Difficulty options
        JPanel difficultyPanel = new JPanel();
        autoCorrect = new JCheckBox("AutoCorrect");
        caffeineMode = new JCheckBox("Caffeine Mode");
        nightShift = new JCheckBox("Night Shift");
        difficultyPanel.add(autoCorrect);
        difficultyPanel.add(caffeineMode);
        difficultyPanel.add(nightShift);
        add(difficultyPanel);

        // Start button
        JButton startButton = new JButton("Start Race");
        startButton.addActionListener(e -> startRace());
        add(startButton);
    }

    private void startRace() {
        // Determine passage length
       String selectedPassage = (String) passageSelector.getSelectedItem();
       int length = 50; // defult to medium passage

       if (selectedPassage.equals("Short Passage (25 Characters)")) {
           length = 25;
       } else if (selectedPassage.equals("Long Passage (100 Characters)")) {
           length = 100;
       }

       TypingRace race = new TypingRace(length);
    
       // Number of Typists
       int count = (int) seatCountSpinner.getValue();
       // Create typist dynamically
         for (int i = 0; i < count; i++) {
             char symbol = (char) ('A' + i);
             String playerName = "Player " + (i + 1);
             double accuracy =0.5 +(Math.random()*0.4);

             // Night shift reduces accuracy by 10%
                if(nightShift.isSelected()){
                    accuracy -=0.1;
                }
            
                double rankAdjustment = mainGUI.getGlobalStats().getRankAdjustment(playerName);
                accuracy += rankAdjustment; // Apply rank-based adjustment

                Typist t = new Typist(symbol, playerName, accuracy);
                race.addTypist(t);
         }
         mainGUI.startRace(race);
    }
}