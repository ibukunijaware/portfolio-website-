package Part1;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * An improvement to the TypingRace program that supports 2-6 typists.


@author Ibukunoluwa Oladunni Ijaware
@version 1.0
*/
public class TypingRace{
    private int passageLength;
    private List<Typist> typists; //This list will hold all the typists participating
    private List<Boolean> mistypedState; // This list will track whether each typist mistyped in the current turn

    //Simulation Constants
    private static final int BURNOUT_DURATION = 3;
    private static final double MISTYPE_BASE_CHANCE = 1.0;

    //Difficulty mode settings
    private static boolean autoCorrectEnabled = false;
    private static boolean caffeineModeEnabled = false;
    private static int turnsElapsed= 0;


    // Constructor of class TypingRace
    public TypingRace (int passageLength){
        this.passageLength = passageLength;
        this.typists = new ArrayList<>();
        this.mistypedState = new ArrayList<>();
    }

    public void startRace(){
        //Reset all typist to starting conditions
        for(Typist typist : typists){
            typist.resetToStart();
        }
        boolean raceFinished = false;
        while(!raceFinished){
            // Take one turn for every typist
            for(int i=0; i< typists.size(); i++){
                boolean result = advanceTypist(typists.get(i));
                mistypedState.set(i, result); // Update mistyped state based on the result of advanceTypist
            }
            printRace();

            //Check win conditions 
            if (isRaceFinished()){
                raceFinished = true;
            }
            try{
                TimeUnit.MILLISECONDS.sleep(200); 
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    
        // Announce the winner
        Typist winner = getWinner();
        if(winner != null){
            System.out.println("The winner is: " + winner.getName());
        }
    }

    public void setDifficultySettings(boolean autoCorrect, boolean caffeineMode, boolean nightShift){
        autoCorrectEnabled = autoCorrect;
        caffeineModeEnabled = caffeineMode;
        // Night shift logic is handled during Typist creation in SetupPanel
    }

    /**
     * Adda a typist to the race. It Supports up to 6 typists. 
     */
    public void addTypist(Typist typist){
        if(typists.size() < 6){
            typists.add(typist);
            mistypedState.add(false); // Initialize mistyped state for this typist
        }
    }

    

    /**
     * The logic for a singlr typist's turn
     * @return true if the typist advanced, false if they mistyped 
     */
    private boolean advanceTypist(Typist theTypist){
        if (theTypist == null ) return false;

        if (theTypist.isBurntOut()) {
            theTypist.recoverFromBurnout();
            return false; // Burnt-out typists cannot advance
        }

        // Burnout check
        double burnoutChance = (0.05* Math.pow(theTypist.getAccuracy(),2));
        if (caffeineModeEnabled && turnsElapsed > 10){
            burnoutChance *=3.0;
        }
        if(Math.random() < burnoutChance){
            theTypist.burnOut(BURNOUT_DURATION);  
            return false;
        }

        double rand = Math.random();
        
        // Type attempt 
        if(rand < theTypist.getAccuracy()){
            theTypist.typeCharacter();
            return false;
        }

        // Mistype check 
        double mistypeChance = (1.0 - theTypist.getAccuracy()) * MISTYPE_BASE_CHANCE;
        if(rand < theTypist.getAccuracy() + mistypeChance){
            int slideBackAmount = autoCorrectEnabled ? 1:2;
            theTypist.slideBack(slideBackAmount);
            return true;
        }

        if(Math.random()<burnoutChance){
            theTypist.burnOut(BURNOUT_DURATION);  
        }
        return false;
    }

    /**
     * Checks if any typist has reached the end of the passage, indicating
     * the race is finished.
     * @return true if the race is finished, false otherwise
     */
    public boolean isRaceFinished(){
        for(Typist typist : typists){
            if(typist != null &&typist.getProgress() >= passageLength){
                return true;
            }
        }
        return false;
    }

    /**
     * Identifies the winner of the race
     */
    public Typist getWinner(){
        for(Typist typist : typists){
            if(typist != null &&typist.getProgress() >= passageLength){
                return typist;
            }
        }
        return null; // No winner yet
    }

    private void printRace(){
        System.out.println('\u000C');
        System.out.println("Typing Race- passage length: " + passageLength + " characters");
        multiplePrint ('=', passageLength + 3);
        System.out.println();

        for(int i=0; i<typists.size(); i++){
            printSeat(typists.get(i), mistypedState.get(i));
            System.out.println();
        }
        multiplePrint ('=', passageLength + 3);
        System.out.println("\n [zz] = Burnt Out | [<] = Mistyped");
    }

    private void printSeat (Typist theTypist, boolean mistyped){
        if(theTypist == null){
            System.out.println("| [Empty seat] |");
            return;
        }

        int currentPos = Math.min(theTypist.getProgress(), passageLength);
        int spaceAfter = passageLength - currentPos;

        System.out.print('|');
        multiplePrint(' ', currentPos);

        System.out.print(theTypist.getSymbol());
        if (theTypist.isBurntOut()){
            System.out.print('~');
        }
        else if(mistyped){
            System.out.print('<');
        }
       multiplePrint(' ', spaceAfter);
        System.out.print('|' );

        System.out.print("" + theTypist.getName() + "(Accuracy: " + theTypist.getAccuracy() + ")");
        if (theTypist.isBurntOut()){
            System.out.print("BURNT OUT (" + theTypist.getBurnoutTurnsRemaining() + " turns remaining)");

        }
    }

    private void multiplePrint(char c, int times){
        for(int i=0; i<times; i++){
            System.out.print(c);
        }
    }
    

    // Required for GUI
    public void step(){
        turnsElapsed++;
        for(int i=0; i< typists.size(); i++){
            boolean result = advanceTypist(typists.get(i));
            mistypedState.set(i, result); // Update mistyped state based on the result of advanceTypist
        }
    }

    public List<Typist> getTypists(){
        return this.typists;
    }

    public int getPassageLength(){
        return this.passageLength;
    }

    public boolean getMistypedState(int index){
       if(index >= 0 && index < mistypedState.size()){
            return mistypedState.get(index);
       }
       return false;
    }
}

